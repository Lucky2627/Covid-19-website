# Covid-19
By the help of this websiteit can collect the information and know near  by testing center.
